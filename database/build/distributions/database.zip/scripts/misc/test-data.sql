INSERT INTO ws_demo.connections (connection_id) VALUES ('1');
INSERT INTO ws_demo.connections (connection_id) VALUES ('2');
INSERT INTO ws_demo.connections (connection_id) VALUES ('3');
